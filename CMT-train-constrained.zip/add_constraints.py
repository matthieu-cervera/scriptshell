import yaml
from utils.hparams import HParams
import os

hparam_file = os.path.join(os.getcwd(), "hparams-constrained.yaml")

with open(hparam_file, 'r') as f:
    config =yaml.safe_load(f)
#config = HParams.load(hparam_file)

def rhythm_constraint_adder(constraint):
    if len(constraint) != 0:
        config['model']['cp']['rhythm']['activate'] = True
        config['model']['cp']['rhythm']['model']['name'] = constraint
        print(config["model"]['cp'])

        # Save changes in hparams.yaml
        with open(hparam_file, 'w') as f:
            yaml.dump(config, f)


rhythm_constraint_adder('rhythmAlldifferent')
