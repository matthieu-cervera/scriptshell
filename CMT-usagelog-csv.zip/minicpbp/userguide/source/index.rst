

.. highlight:: java
   :linenothreshold: 4


####################################################
MiniCP: A lightweight Constraint Programming Solver
####################################################

.. toctree::
   :maxdepth: 2

   intro
   minicp
   about
	




.. Indices and tables
.. ==================

.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`

