.. _about:

*******
About
*******


`Laurent Michel <http://ash.engr.uconn.edu/~ldm/work/>`_ is Professor at the University of Connecticut.

`Pierre Schaus <http://www.info.ucl.ac.be/~pschaus/>`_ is Professor at UCLouvain.

`Pascal Van Hentenryck <http://pwp.gatech.edu/pascal-van-hentenryck/>`_ is Professor at Georgia Tech.










